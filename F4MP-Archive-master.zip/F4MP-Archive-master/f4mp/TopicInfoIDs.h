#pragma once

namespace f4mp
{
	extern UInt32 topicInfoIDs[68227];
}