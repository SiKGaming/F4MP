#define ZPL_IMPLEMENTATION
#define ZPL_NO_MATH_H
#include <zpl.h>

int main() {
    return 0;
}
