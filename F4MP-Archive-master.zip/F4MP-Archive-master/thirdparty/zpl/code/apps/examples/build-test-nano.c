#define ZPL_IMPLEMENTATION
#define ZPL_NANO
#include <zpl.h>

int main() {
    return 0;
}
